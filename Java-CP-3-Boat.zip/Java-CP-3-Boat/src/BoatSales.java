import java.nio.charset.Charset;
import java.text.*;
import java.util.*;

public class BoatSales {
// declare variables
	static String iString, oQty, oBoatCost, oAccCost, oPrepCost, oMarkAm, oSubTotal, oTax, oTotal, oBoatLit, oAccLit, oGtSales; //output vars
	static String moreRecs = "Y", iBoatType; //loop var
	static double cBoatCost, cPrepCost, cMarkAm, cSubTotal, cTax, cTotal, cAccCost, iMarkPerc, cGtSales = 0.00; //input/calc'd vars
	static int iAccType, cQty, cSctr = 0;//inputs and counter
	static Scanner myScanner; //input device
	static NumberFormat nfc; //formatting to currency
	
/*	
	static String iString; //helps convert some inputs to numbers
	static String iFName, iLName, iToy1, iToy2; //variables for the names of the objects
	static double iToy1Price, iToy2Price, cSubTotal, cTax, cTotal;
	static String oToy1Price, oToy2Price, oSubTotal, oTax, oTotal; 
	static Scanner myScanner; //input device
	static NumberFormat nfc; //used for formatting to currency
	static String iChoice;
*/
	
public static void main(String [] args) {
	
		//call initialization
		init();
		
		do { //loop
		//call input
		input();
		
		//call calculations
		calc();
		
		//call output
		output();
		}while(moreRecs=="Y");
		
		//call closing
		closing();
		
		System.out.println("Program Completed Successfully");
	
	}

	static void init() {
		//set scanner to console
		myScanner = new Scanner(System.in);
		
		//change delimiter from blank space to enter key
		//to allow spaces in strings
		myScanner.useDelimiter(System.getProperty("line.separator"));
				
		//set formatter to use U.S. currency format
		nfc = NumberFormat.getCurrencyInstance(java.util.Locale.US);
	}



	public static void input() {
		System.out.print("Enter your boat type, either B for Bass, P for Pontoon, S for Ski and C for Canoe: ");
		iBoatType = myScanner.next();
		
			switch(iBoatType.toUpperCase()) {
		case "B":
			iMarkPerc = .33;
			oBoatLit = "Bass";
			break;
		case "P":
			iMarkPerc = .25;
			oBoatLit = "Pontoon";
			break;
		case "S":
			iMarkPerc = .425;
			oBoatLit = "Ski";
			break;
		case "C":
			iMarkPerc = .20;
			oBoatLit = "Canoe";
			break;
		default:
			System.out.println("That is not a valid input. Pick one of the options given above. ");
			input();
			}
			
			
		do {
			try {
				System.out.print("Enter your accessory type, either �1� for Electronics, �2� for the Ski Package, or �3� for the Fishing Package: ");
				iString = myScanner.next();
				iAccType = Integer.parseInt(iString);
				if(iAccType < 1 || iAccType > 3) {
					System.out.println("Entry must be one of the given choices, please re-enter: ");
				}
			}
			catch (Exception e) {
				System.out.println("Entry must be one of the given choices, please re-enter: ");
				iAccType = 0;  
			}
		}while(iAccType < 1 || iAccType > 3);
		
		//System.out.print("Enter your accessory type, either �1� for Electronics, �2� for the Ski Package, or �3� for the Fishing Package: ");
		//iString = myScanner.next();
		//iAccType = Integer.parseInt(iString);
		
			switch(iAccType) {
		case 1:
			cAccCost = 5415.30;
			oAccLit = "Electronics";
			break;
		case 2:
			cAccCost = 3980;
			oAccLit = "Ski Package";
			break;
		case 3:
			iMarkPerc = 345.45;
			oBoatLit = "Fishing Package";
			break;
		default:
			System.out.println("That is not a valid input. Pick one of the options given above. ");
			
			}

			
		do {
			try {
				System.out.print("Enter the quantity: ");
				iString = myScanner.next();
				cQty = Integer.parseInt(iString);
				if(cQty <1 || cQty >25) {
					System.out.println("Your quantity must be numerical and be between 1 and 25, please re-enter: ");
				}
			}
			catch(Exception e){
				System.out.println("Quantity must be numerical and be between 1 and 25, please re-enter: ");
				cQty = 0;  
			}
		}while(cQty <1 || cQty >25);	
			
			
		do {
			try {
				System.out.print("Enter the boat cost, between 2500 and 150000: ");
				iString = myScanner.next();
				cBoatCost = Double.parseDouble(iString);
				if(cBoatCost <2500 || cBoatCost >150000) {
					System.out.println("Your boat cost must be numerical and be between 2500 and 150000, please re-enter: ");
				}
			}
			catch(Exception e){
				System.out.println("Boat Cost must be numerical and be between 2500 and 150000, please re-enter: ");
				cBoatCost = 0;  
			}
		}while(cBoatCost <2500 || cBoatCost >150000);	
			
		
		do {
			try {
				System.out.print("Enter the prep cost, between 100 and 9999.99: ");
				iString = myScanner.next();
				cPrepCost = Double.parseDouble(iString);
				if(cPrepCost <100 || cPrepCost >9999.99) {
					System.out.println("Your prep cost must be numerical and be between 2500 and 150000, please re-enter: ");
				}
			}
			catch(Exception e){
				System.out.println("Prep Cost must be numerical and be between 2500 and 150000, please re-enter: ");
				cPrepCost = 0;  
			}
		}while(cPrepCost <100 || cPrepCost >9999.99);	
		
		
		}

	public static void calc() {
		
		cSctr += 1;
		cMarkAm = iMarkPerc * cBoatCost;
		
		cSubTotal = (cBoatCost + cAccCost + cPrepCost + cMarkAm) * cQty;
		cTax = cSubTotal *.06;
		cTotal = cTax + cSubTotal;
		cGtSales += cTotal;

		}
	
	public static void output() {
		//Format and Display
		
		
		System.out.println("Your Boat: " + oBoatLit);
		
		System.out.println("Your Accessory: " + oAccLit);
		
		oQty = NumberFormat.getInstance().format(cQty);
		System.out.println("Your Qty: " + oQty);
		
		oBoatCost = nfc.format(cBoatCost);
		System.out.println("Your Boat Cost: " + oBoatCost);
		
		oAccCost = nfc.format(cAccCost);
		System.out.println("Your Acc Cost: " + oAccCost);
		
		oPrepCost = nfc.format(cPrepCost);
		System.out.println("Your Prep Cost: " + oPrepCost);
		
		oMarkAm = nfc.format(cMarkAm);
		System.out.println("Your Markup Amount: " + oMarkAm);
		
		oSubTotal = nfc.format(cSubTotal);
		System.out.println("Your SubTotal: " + oSubTotal);
		
		oTax = nfc.format(cTax);
		System.out.println("Your Tax: " + oTax);
		
		oTotal = nfc.format(cTotal);
		System.out.println("Your Total: " + oTotal);
		
		System.out.print("Enter Y/y to input another receipt or enter anything else to see the grand total." );
		moreRecs = myScanner.next();
		if (moreRecs =="y" || moreRecs =="Y") {
			input();
		}
	}
	
	public static void closing() {
		oGtSales = nfc.format(cGtSales);
		System.out.print("Your Grand Total: " + oGtSales + " ");
	}
}